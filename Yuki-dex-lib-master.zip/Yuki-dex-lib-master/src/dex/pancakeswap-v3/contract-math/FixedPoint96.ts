export class FixedPoint96 {
  static readonly RESOLUTION = 96n;
  static readonly Q96 = 0x1000000000000000000000000n;
}

export class FixedPoint128 {
  static readonly Q128 = 0x100000000000000000000000000000000n;
}
